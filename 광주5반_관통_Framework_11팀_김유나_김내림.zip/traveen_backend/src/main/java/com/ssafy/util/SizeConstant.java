package com.ssafy.util;

public class SizeConstant {

	public final static int LIST_SIZE = 20;
	public final static int NAVIGATION_SIZE = 10;
	public final static int TRIPINFO_LIST_SIZE = 16;
	public final static int TRIPINFO_NAVIGATION_SIZE = 5;
	
}
